# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/home/Xilinx/Vivado/2019.2/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xcu280-fsvh2892-2L-e ../ethz_systems_fpga_hls_rocev2_0_82.zip
